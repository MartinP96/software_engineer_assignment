"""
    File name: __init__py
    Date: 02.01.2023
"""

from software_engineer_assignment.__main__ import app
